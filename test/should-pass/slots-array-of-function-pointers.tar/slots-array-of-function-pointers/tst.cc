// -*- mode: C++; c-basic-offset: 2; tab-width: 2; indent-tabs-mode: nil -*-

typedef int foo_t;
typedef void (*func_t)();
typedef int bar_t[2];
typedef void* ptr_seq_t[2];

typedef void (*func_seq_t[2])();

void func()
{
}

int main()
{
  func_seq_t func_seq;

  func_seq[0] = func;
  func_seq[1] = func;
  
  return 0;
}
